import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import styled from 'styled-components';
import { FaEdit, FaTrash, FaEye, FaSearch, FaDatabase } from 'react-icons/fa';

const Container = styled.div`
  background: white;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-top: 20px;
`;

const Title = styled.h1`
  color: #2c3e50;
  margin-bottom: 20px;
  display: flex;
  align-items: center;
  gap: 10px;
`;

const SearchBar = styled.div`
  display: flex;
  margin-bottom: 20px;
  position: relative;
  
  input {
    padding-left: 40px;
  }
  
  svg {
    position: absolute;
    left: 10px;
    top: 50%;
    transform: translateY(-50%);
    color: #7f8c8d;
  }
`;

const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
  
  th, td {
    padding: 12px 15px;
    text-align: left;
    border-bottom: 1px solid #ddd;
  }
  
  th {
    background-color: #f8f9fa;
    color: #2c3e50;
    font-weight: 600;
  }
  
  tr:hover {
    background-color: #f5f5f5;
  }
`;

const ActionButtons = styled.div`
  display: flex;
  gap: 10px;
`;

const ViewButton = styled(Link)`
  background: #3498db;
  color: white;
  padding: 6px 12px;
  border-radius: 4px;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  
  &:hover {
    background: #2980b9;
  }
`;

const EditButton = styled(Link)`
  background: #2ecc71;
  color: white;
  padding: 6px 12px;
  border-radius: 4px;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  
  &:hover {
    background: #27ae60;
  }
`;

const DeleteButton = styled.button`
  background: #e74c3c;
  color: white;
  padding: 6px 12px;
  border-radius: 4px;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  
  &:hover {
    background: #c0392b;
  }
`;

const EmptyMessage = styled.div`
  text-align: center;
  padding: 20px;
  color: #7f8c8d;
  font-size: 18px;
`;

const LoadingSpinner = styled.div`
  text-align: center;
  padding: 20px;
  color: #3498db;
  font-size: 18px;
`;

const UsersList = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const response = await axios.get('http://localhost:5001/api/users');
      setUsers(response.data);
      setError(null);
    } catch (err) {
      setError('Ошибка при загрузке пользователей. Пожалуйста, проверьте подключение к серверу.');
      console.error('Error fetching users:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Вы уверены, что хотите удалить этого пользователя?')) {
      try {
        await axios.delete(`http://localhost:5001/api/users/${id}`);
        setUsers(users.filter(user => user.id !== id));
      } catch (err) {
        setError('Ошибка при удалении пользователя');
        console.error('Error deleting user:', err);
      }
    }
  };

  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Container>
      <Title>
        <FaDatabase /> Список пользователей
      </Title>
      
      <SearchBar>
        <FaSearch />
        <input 
          type="text" 
          placeholder="Поиск по имени, городу или email..." 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </SearchBar>
      
      {loading ? (
        <LoadingSpinner>Загрузка пользователей...</LoadingSpinner>
      ) : error ? (
        <EmptyMessage>{error}</EmptyMessage>
      ) : filteredUsers.length === 0 ? (
        <EmptyMessage>
          {searchTerm ? 'Пользователи не найдены' : 'Нет доступных пользователей'}
        </EmptyMessage>
      ) : (
        <Table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Имя</th>
              <th>Город</th>
              <th>Email</th>
              <th>Возраст</th>
              <th>Время регистрации</th>
              <th>Действия</th>
            </tr>
          </thead>
          <tbody>
            {filteredUsers.map(user => (
              <tr key={user.id}>
                <td>{user.id}</td>
                <td>{user.name}</td>
                <td>{user.city}</td>
                <td>{user.email}</td>
                <td>{user.age}</td>
                <td>{user.time_slot ? new Date(user.time_slot).toLocaleString() : 'N/A'}</td>
                <td>
                  <ActionButtons>
                    <ViewButton to={`/users/${user.id}`}>
                      <FaEye /> Просмотр
                    </ViewButton>
                    <EditButton to={`/edit/${user.id}`}>
                      <FaEdit /> Изменить
                    </EditButton>
                    <DeleteButton onClick={() => handleDelete(user.id)}>
                      <FaTrash /> Удалить
                    </DeleteButton>
                  </ActionButtons>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}
    </Container>
  );
};

export default UsersList;