import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import styled from 'styled-components';
import { FaUser, FaEdit, FaArrowLeft } from 'react-icons/fa';

const Container = styled.div`
  background: white;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-top: 20px;
`;

const Title = styled.h1`
  color: #2c3e50;
  margin-bottom: 20px;
  display: flex;
  align-items: center;
  gap: 10px;
`;

const UserInfo = styled.div`
  margin-top: 20px;
`;

const InfoItem = styled.div`
  margin-bottom: 15px;
  padding-bottom: 15px;
  border-bottom: 1px solid #eee;
  
  &:last-child {
    border-bottom: none;
  }
`;

const Label = styled.span`
  font-weight: 600;
  color: #7f8c8d;
  display: block;
  margin-bottom: 5px;
`;

const Value = styled.span`
  font-size: 18px;
  color: #2c3e50;
`;

const ButtonGroup = styled.div`
  display: flex;
  gap: 10px;
  margin-top: 20px;
`;

const Button = styled(Link)`
  padding: 10px 15px;
  border-radius: 4px;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-weight: 600;
`;

const BackButton = styled(Button)`
  background: #7f8c8d;
  color: white;
  
  &:hover {
    background: #95a5a6;
  }
`;

const EditButton = styled(Button)`
  background: #2ecc71;
  color: white;
  
  &:hover {
    background: #27ae60;
  }
`;

const LoadingMessage = styled.div`
  text-align: center;
  padding: 20px;
  color: #3498db;
  font-size: 18px;
`;

const ErrorMessage = styled.div`
  text-align: center;
  padding: 20px;
  color: #e74c3c;
  font-size: 18px;
`;

const UserDetails = () => {
  const { id } = useParams();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const response = await axios.get(`http://localhost:5001/api/users/${id}`);
        setUser(response.data);
        setError(null);
      } catch (err) {
        setError('Не удалось загрузить данные пользователя');
        console.error('Error fetching user:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, [id]);

  if (loading) {
    return <LoadingMessage>Загрузка данных пользователя...</LoadingMessage>;
  }

  if (error) {
    return <ErrorMessage>{error}</ErrorMessage>;
  }

  if (!user) {
    return <ErrorMessage>Пользователь не найден</ErrorMessage>;
  }

  return (
    <Container>
      <Title>
        <FaUser /> Информация о пользователе
      </Title>
      
      <UserInfo>
        <InfoItem>
          <Label>ID:</Label>
          <Value>{user.id}</Value>
        </InfoItem>
        
        <InfoItem>
          <Label>Имя:</Label>
          <Value>{user.name}</Value>
        </InfoItem>
        
        <InfoItem>
          <Label>Город:</Label>
          <Value>{user.city}</Value>
        </InfoItem>
        
        <InfoItem>
          <Label>Email:</Label>
          <Value>{user.email}</Value>
        </InfoItem>
        
        <InfoItem>
          <Label>Возраст:</Label>
          <Value>{user.age}</Value>
        </InfoItem>

        <InfoItem>
          <Label>Время регистрации:</Label>
          <Value>{new Date(user.time_slot).toLocaleString('ru-RU')}</Value>
        </InfoItem>
      </UserInfo>
      
      <ButtonGroup>
        <BackButton to="/">
          <FaArrowLeft /> Назад к списку
        </BackButton>
        
        <EditButton to={`/edit/${user.id}`}>
          <FaEdit /> Редактировать
        </EditButton>
      </ButtonGroup>
    </Container>
  );
};

export default UserDetails;