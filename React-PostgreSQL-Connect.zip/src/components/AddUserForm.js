import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import styled from 'styled-components';
import { FaUserPlus } from 'react-icons/fa';

const Container = styled.div`
  background: white;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-top: 20px;
`;

const Title = styled.h1`
  color: #2c3e50;
  margin-bottom: 20px;
  display: flex;
  align-items: center;
  gap: 10px;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
`;

const FormGroup = styled.div`
  margin-bottom: 15px;
`;

const Label = styled.label`
  display: block;
  margin-bottom: 5px;
  font-weight: 600;
  color: #2c3e50;
`;

const Input = styled.input`
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 16px;
  
  &:focus {
    outline: none;
    border-color: #3498db;
    box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
  }
`;

const ErrorMessage = styled.div`
  color: #e74c3c;
  margin-top: 5px;
  font-size: 14px;
`;

const Button = styled.button`
  background: #3498db;
  color: white;
  padding: 10px 15px;
  border: none;
  border-radius: 4px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  margin-top: 10px;
  
  &:hover {
    background: #2980b9;
  }
  
  &:disabled {
    background: #95a5a6;
    cursor: not-allowed;
  }
`;

const AddUserForm = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    city: '',
    email: '',
    age: '',
    time_slot: ''
  });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    // Clear error when user types
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };

  const validate = () => {
    const newErrors = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Имя обязательно для заполнения';
    }
    
    if (!formData.city.trim()) {
      newErrors.city = 'Город обязателен для заполнения';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email обязателен для заполнения';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Некорректный формат email';
    }
    
    if (!formData.age) {
      newErrors.age = 'Возраст обязателен для заполнения';
    } else if (isNaN(formData.age) || parseInt(formData.age) <= 0) {
      newErrors.age = 'Возраст должен быть положительным числом';
    }
    
    if (!formData.time_slot) {
      newErrors.time_slot = 'Необходимо выбрать время регистрации';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validate()) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const localDate = new Date(formData.time_slot);
      await axios.post('http://localhost:5001/api/users', {
        ...formData,
        age: parseInt(formData.age),
        time_slot: localDate.toISOString()
      });
      
      setSuccessMessage('Пользователь успешно зарегистрирован!');
      setTimeout(() => {
        navigate('/');
      }, 2000);
    } catch (err) {
      if (err.response && err.response.data.error) {
        setErrors({ submit: err.response.data.error });
      } else {
        setErrors({ submit: 'Произошла ошибка при добавлении пользователя' });
      }
      console.error('Error adding user:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Container>
      <Title>
        <FaUserPlus /> Добавить нового пользователя
      </Title>
      
      <Form onSubmit={handleSubmit}>
        <FormGroup>
          <Label htmlFor="name">Имя</Label>
          <Input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
          />
          {errors.name && <ErrorMessage>{errors.name}</ErrorMessage>}
        </FormGroup>
        
        <FormGroup>
          <Label htmlFor="city">Город</Label>
          <Input
            type="text"
            id="city"
            name="city"
            value={formData.city}
            onChange={handleChange}
          />
          {errors.city && <ErrorMessage>{errors.city}</ErrorMessage>}
        </FormGroup>
        
        <FormGroup>
          <Label htmlFor="time_slot">Время регистрации</Label>
          <Input
            type="datetime-local"
            id="time_slot"
            name="time_slot"
            value={formData.time_slot}
            onChange={handleChange}
          />
          {errors.time_slot && <ErrorMessage>{errors.time_slot}</ErrorMessage>}
        </FormGroup>

        <FormGroup>
          <Label htmlFor="email">Email</Label>
          <Input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
          />
          {errors.email && <ErrorMessage>{errors.email}</ErrorMessage>}
        </FormGroup>
        
        <FormGroup>
          <Label htmlFor="age">Возраст</Label>
          <Input
            type="number"
            id="age"
            name="age"
            value={formData.age}
            onChange={handleChange}
          />
          {errors.age && <ErrorMessage>{errors.age}</ErrorMessage>}
        </FormGroup>
        
        {errors.submit && <ErrorMessage>{errors.submit}</ErrorMessage>}
        
        {successMessage && (
          <div style={{ color: '#2ecc71', marginBottom: '15px', fontWeight: 'bold' }}>
            {successMessage}
          </div>
        )}
        
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? 'Добавление...' : 'Добавить пользователя'}
        </Button>
      </Form>
    </Container>
  );
};

export default AddUserForm;