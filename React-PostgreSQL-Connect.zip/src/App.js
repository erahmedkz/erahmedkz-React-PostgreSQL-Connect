import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import styled from 'styled-components';
import Navbar from './components/Navbar';
import UsersList from './components/UsersList';
import AddUserForm from './components/AddUserForm';
import EditUserForm from './components/EditUserForm';
import UserDetails from './components/UserDetails';
import { FaDatabase } from 'react-icons/fa';

const AppContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
`;

const Footer = styled.footer`
  text-align: center;
  margin-top: 40px;
  padding: 20px;
  color: #7f8c8d;
  font-size: 14px;
`;

const App = () => {
  return (
    <Router>
      <Navbar />
      <AppContainer>
        <Routes>
          <Route path="/" element={<UsersList />} />
          <Route path="/add" element={<AddUserForm />} />
          <Route path="/edit/:id" element={<EditUserForm />} />
          <Route path="/users/:id" element={<UserDetails />} />
        </Routes>
        <Footer>
          <p>React-PostgreSQL-Connect &copy; {new Date().getFullYear()}</p>
          <p>Учебный проект для работы с React и PostgreSQL</p>
        </Footer>
      </AppContainer>
    </Router>
  );
};

export default App;
