const { Pool } = require('pg');

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'react_postgres_users',
  password: '12345',
  port: 5432,
});

async function resetDatabase() {
  try {
    console.log('Начинаем сброс базы данных...');
    
    // Удаляем существующую таблицу
    await pool.query('DROP TABLE IF EXISTS users');
    console.log('✅ Таблица users удалена');
    
    // Создаем таблицу заново
    await pool.query(`
      CREATE TABLE users (
        id SERIAL PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        city VARCHAR(100) NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        age INTEGER CHECK (age > 0),
        time_slot TIMESTAMP WITH TIME ZONE UNIQUE NOT NULL
      )
    `);
    console.log('✅ Таблица users создана заново');
    
    // Добавляем тестовые данные
    await pool.query(`
      INSERT INTO users (name, city, email, age, time_slot) VALUES 
      ('Тойшыбаев Жаслан', 'Астана', 'zhaskr@gmail.com', 17, '2024-03-20 10:00:00'),
      ('Биржанов Арлан', 'Алматы', 'arbir@gmail.com', 16, '2024-03-20 11:00:00'),
      ('Ермек Ахмед', 'Туркестан', 'ahmedkz@gmail.com', 18, '2024-03-20 12:00:00')
    `);
    console.log('✅ Тестовые данные добавлены');
    
    console.log('✅ База данных успешно сброшена!');
  } catch (err) {
    console.error('❌ Ошибка при сбросе базы данных:', err);
  } finally {
    pool.end();
  }
}

resetDatabase();