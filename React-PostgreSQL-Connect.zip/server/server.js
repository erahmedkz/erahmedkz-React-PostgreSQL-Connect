const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');

const app = express();
const port = 5001;

// Middleware
app.use(cors());
app.use(express.json());

// Настройка подключения к PostgreSQL
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'react_postgres_users',
  password: '12345',
  port: 5432,
});

// Проверка подключения
pool.connect()
  .then(() => console.log('✅ Подключение к PostgreSQL успешно установлено!'))
  .catch(err => console.error('❌ Ошибка подключения к PostgreSQL:', err));

// Получение всех пользователей
app.get('/api/users', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM users ORDER BY id ASC');
    res.json(result.rows);
  } catch (err) {
    console.error('Ошибка при получении пользователей:', err);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});

// Получение одного пользователя по ID
app.get('/api/users/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query('SELECT * FROM users WHERE id = $1', [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Пользователь не найден' });
    }
    res.json(result.rows[0]);
  } catch (err) {
    console.error('Ошибка при получении пользователя:', err);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});

// Создание нового пользователя
app.post('/api/users', async (req, res) => {
  const { name, city, email, age, time_slot } = req.body;
  
  if (!name || !city || !email || !age || !time_slot) {
    return res.status(400).json({ error: 'Все поля обязательны для заполнения' });
  }
  
  try {
    const result = await pool.query(
      'INSERT INTO users (name, city, email, age, time_slot) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [name, city, email, age, time_slot]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('Ошибка при создании пользователя:', err);
    if (err.code === '23505') {
      if (err.constraint === 'users_email_key') {
        return res.status(400).json({ error: 'Пользователь с таким email уже существует' });
      } else if (err.constraint === 'users_time_slot_key') {
        return res.status(400).json({ error: 'Это время регистрации уже занято' });
      }
    }
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});

// Обновление пользователя
app.put('/api/users/:id', async (req, res) => {
  const { id } = req.params;
  const { name, city, email, age, time_slot } = req.body;
  
  if (!name || !city || !email || !age || !time_slot) {
    return res.status(400).json({ error: 'Все поля обязательны для заполнения' });
  }
  
  try {
    const result = await pool.query(
      'UPDATE users SET name = $1, city = $2, email = $3, age = $4, time_slot = $5 WHERE id = $6 RETURNING *',
      [name, city, email, age, time_slot, id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Пользователь не найден' });
    }
    
    res.json(result.rows[0]);
  } catch (err) {
    console.error('Ошибка при обновлении пользователя:', err);
    if (err.code === '23505') {
      if (err.constraint === 'users_email_key') {
        return res.status(400).json({ error: 'Пользователь с таким email уже существует' });
      } else if (err.constraint === 'users_time_slot_key') {
        return res.status(400).json({ error: 'Это время регистрации уже занято' });
      }
    }
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});

// Удаление пользователя
app.delete('/api/users/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query('DELETE FROM users WHERE id = $1 RETURNING *', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Пользователь не найден' });
    }
    
    // Находим минимальный свободный ID
    const allIds = await pool.query('SELECT id FROM users ORDER BY id');
    
    // Если нет пользователей, сбрасываем последовательность на 1
    if (allIds.rows.length === 0) {
      await pool.query(`ALTER SEQUENCE users_id_seq RESTART WITH 1`);
    } else {
      // Ищем первый пропуск в последовательности ID
      let foundGap = false;
      let minGapId = 1;
      
      for (let i = 0; i < allIds.rows.length; i++) {
        if (allIds.rows[i].id !== i + 1) {
          minGapId = i + 1;
          foundGap = true;
          break;
        }
      }
      
      // Если пропуск не найден, используем следующий ID после максимального
      if (!foundGap) {
        minGapId = allIds.rows.length + 1;
      }
      
      // Сбрасываем последовательность на найденный минимальный свободный ID
      await pool.query(`ALTER SEQUENCE users_id_seq RESTART WITH ${minGapId}`);
    }
    
    res.json({ message: 'Пользователь успешно удален', user: result.rows[0] });
  } catch (err) {
    console.error('Ошибка при удалении пользователя:', err);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});

app.listen(port, () => {
  console.log(`Сервер запущен на порту ${port}`);
});